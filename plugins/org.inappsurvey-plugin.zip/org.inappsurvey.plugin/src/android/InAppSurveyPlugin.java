package org.inappsurvey.plugin;


import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import org.apache.cordova.CordovaPlugin;
import org.apache.cordova.CallbackContext;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.List;


/**
 * This class echoes a string called from JavaScript.
 */
public class InAppSurveyPlugin extends CordovaPlugin {

    @Override
    public boolean execute(String action, JSONArray args, CallbackContext callbackContext) throws JSONException {
        if (action.equals("getAppDetails")) {
            String name = ""+getAppUID();

            JSONObject joAppDetails = new JSONObject();
            joAppDetails.put("AppName", getApplicationName(cordova.getActivity().getApplicationContext()));
            joAppDetails.put("AppUID", name);

            String sendResult = joAppDetails.toString();
            this.getAppDetails(sendResult, callbackContext);
            return true;
        }
        return false;
    }

    private void getAppDetails(String message, CallbackContext callbackContext) {
        if (message != null && message.length() > 0) {
            callbackContext.success(message);
        } else {
            callbackContext.error("Expected one non-empty string argument.");
        }
    }
    public int getAppUID(){
        final PackageManager pm = cordova.getActivity().getApplicationContext().getPackageManager();
        //get a list of installed apps.
        List<ApplicationInfo> packages = pm.getInstalledApplications(
                PackageManager.GET_META_DATA);
        int UID = 0;
        //loop through the list of installed packages and see if the selected
        //app is in the list
        for (ApplicationInfo packageInfo : packages) {
            if(packageInfo.packageName.equals(cordova.getActivity().getApplicationContext().getPackageName())){
                //get the UID for the selected app
                UID = packageInfo.uid;
                break; //found a match, don't need to search anymore
            }

        }
        return UID;
    }
    public static String getApplicationName(Context context) {
        ApplicationInfo applicationInfo = context.getApplicationInfo();
        int stringId = applicationInfo.labelRes;
        return stringId == 0 ? applicationInfo.nonLocalizedLabel.toString() : context.getString(stringId);
    }
}
