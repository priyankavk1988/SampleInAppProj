document.addEventListener("deviceready", onDeviceReady, false);

alert("entered on device ready");
function onDeviceReady() {
	

    var URL = "https://inappsurvey20180420090149.azurewebsites.net/api/survey?appname=";
	cordova.exec(successCallBack, failureCallBack, "InAppSurveyPlugin", "greet", ['name']);

//    cordova.exec(successCallBack,failureCallBack, "InAppSurveyPlugin", "getAppDetails",['test']);
    
}

function successCallBack(success){
    debugger;
	console.log(success);
    alert(success);
	alert("test URL https://inappsurvey20180420090149.azurewebsites.net/api/survey?appname="+JSON.parse(success).AppName);

    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            injectIFrame();
        }
    };
//	JSON.parse(success).AppName
    xhttp.open("GET","https://inappsurvey20180420090149.azurewebsites.net/api/survey?appname="+JSON.parse(success).AppName, true);
    xhttp.send();
}

function failureCallBack(fail){
	console.log(fail);
    alert(fail);
}

function injectIFrame() {
	debugger;
	console.log("reached injectIFrame");
    var iframe = document.createElement('iframe');
	iframe.width = '100%';iframe.height = '100%';

    document.body.appendChild(iframe);

    iframe.src = 'https://inappsurvey20180420090149.azurewebsites.net/SurveyUI';

}